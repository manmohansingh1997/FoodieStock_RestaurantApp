package com.sonuproject.foodiestock.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.sonuproject.foodiestock.R
import com.sonuproject.foodiestock.activity.RestMenu
import com.sonuproject.foodiestock.database.FoodEntity
import com.sonuproject.foodiestock.fragment.HomeFragment
import com.sonuproject.foodiestock.model.Food
import com.squareup.picasso.Picasso


class HomeRecyclerAdapter(val context: Context, var itemList: ArrayList<Food>) :
    RecyclerView.Adapter<HomeRecyclerAdapter.HomeViewHolder>()
{
    class HomeViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val txtRestroName: TextView = view.findViewById(R.id.txtRestroName)
        val txtItemPrice: TextView = view.findViewById(R.id.txtfoodPrice)
        val txtFoodRating: TextView = view.findViewById(R.id.txtFoodRating)
        val txtFoodImage: ImageView = view.findViewById(R.id.imgRestroimage)

        val llContent: LinearLayout = view.findViewById(R.id.llContent)
        val favButton: ImageView = view.findViewById(R.id.fav_button)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HomeViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.recycler_home_single_row, parent, false)
        return HomeViewHolder(view)
    }

    override fun getItemCount(): Int {
        return itemList.size
    }

    override fun getItemViewType(position: Int): Int {
        return position
    }

    override fun onBindViewHolder(holder: HomeViewHolder, position: Int) {

        val food = itemList[position]
        holder.txtRestroName.text = food.foodName
        holder.txtItemPrice.text = food.foodPrice.toString()

        holder.txtFoodRating.text = food.foodRating
        Picasso.get().load(food.foodImage).error(R.drawable.splashfoodimage)
            .into(holder.txtFoodImage)

        holder.llContent.setOnClickListener(View.OnClickListener {

            println(holder.txtRestroName.getTag().toString())

            val intent = Intent(context, RestMenu::class.java)
            intent.putExtra("id", holder.txtRestroName.getTag().toString())
            intent.putExtra("name", holder.txtRestroName.text.toString())

            context.startActivity(intent)

            Toast.makeText(
                context, "Clicked on ${holder.txtRestroName.text}",
                Toast.LENGTH_SHORT
            ).show()
        })

        holder.txtRestroName.setTag(food.foodId.toString() + "")
        val foodEntity = FoodEntity(

            food.foodId,
            food.foodName,
            food.foodPrice.toString(),
            food.foodRating,

            food.foodImage
        )
        val checkFav = HomeFragment.DBAsyncTask(context, foodEntity, 1).execute()
        val isFav = checkFav.get()
        if (isFav) {
            val favColor = ContextCompat.getDrawable(context, R.drawable.ic_fav)
            holder.favButton.setImageDrawable(favColor)

        } else {
            val noFavColor = ContextCompat.getDrawable(context, R.drawable.ic_favourite)
            holder.favButton.setImageDrawable(noFavColor)
        }
        holder.favButton.setOnClickListener {
            if (!HomeFragment.DBAsyncTask(context, foodEntity, 1).execute().get()) {
                val async =
                    HomeFragment.DBAsyncTask(context, foodEntity, 2).execute()
                val result = async.get()
                if (result) {
                    Toast.makeText(context, "Added To Favourite", Toast.LENGTH_SHORT).show()
                    val favColor = ContextCompat.getDrawable(context, R.drawable.ic_fav)
                    holder.favButton.setImageDrawable(favColor)
                } else {
                    Toast.makeText(context, "Removed From Favourite", Toast.LENGTH_SHORT).show()
                    val noFavColor = ContextCompat.getDrawable(context, R.drawable.ic_favourite)
                    holder.favButton.setImageDrawable(noFavColor)
                }
            } else {
                val async =
                    HomeFragment.DBAsyncTask(context, foodEntity, 3).execute()
                val result = async.get()

                if (result) {
                    Toast.makeText(context, "Removed From Favourites", Toast.LENGTH_SHORT).show()
                    val noFavColor = ContextCompat.getDrawable(context, R.drawable.ic_favourite)
                    holder.favButton.setImageDrawable(noFavColor)
                } else {
                    Toast.makeText(context, "Error Occurred", Toast.LENGTH_SHORT).show()

                }
            }
        }


    }

    fun filterList(filteredList: ArrayList<Food>) {//to update the recycler view depending on the search
        itemList = filteredList
        notifyDataSetChanged()
    }
}