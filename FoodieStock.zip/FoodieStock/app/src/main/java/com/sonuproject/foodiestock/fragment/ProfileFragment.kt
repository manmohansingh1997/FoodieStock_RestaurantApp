package com.sonuproject.foodiestock.fragment

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.FragmentActivity
import com.sonuproject.foodiestock.R
import kotlinx.android.synthetic.main.fragment_profile.*

/**
 * A simple [Fragment] subclass.
 */
class ProfileFragment : Fragment() {


    lateinit var username: TextView
    lateinit var mobile: TextView
    lateinit var email: TextView
    lateinit var delivery: TextView
    lateinit var sharedPreferences: SharedPreferences

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment

        sharedPreferences = (activity as FragmentActivity).getSharedPreferences(
            getString(R.string.preference_file_name),
            Context.MODE_PRIVATE
        )
        val view = inflater.inflate(R.layout.fragment_profile, container, false)



        username = view.findViewById(R.id.name)
        mobile = view.findViewById(R.id.phone)
        email = view.findViewById(R.id.mail)
        delivery = view.findViewById(R.id.address)


        username.text = sharedPreferences.getString("name", "Name")
        mobile.text = sharedPreferences.getString("mobile_number", "Mobile")
        email.text = sharedPreferences.getString("email", "Email")
        delivery.text = sharedPreferences.getString("address", "Address")




        return view
    }


}
