package com.sonuproject.foodiestock.activity

import android.app.Activity
import android.app.AlertDialog
import android.app.PendingIntent.getActivity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Paint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.*
import androidx.core.app.ActivityCompat
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.sonuproject.foodiestock.R
import com.sonuproject.foodiestock.fragment.HomeFragment
import com.sonuproject.foodiestock.util.ConnectionManager
import kotlinx.android.synthetic.main.activity_login.*
import org.json.JSONException
import org.json.JSONObject

class Login : AppCompatActivity() {

    lateinit var txtforgot: TextView
    lateinit var txtRegister: TextView

    /*lateinit var loginimage: ImageView*/
    lateinit var btnLogin: Button
    lateinit var etMobileNumber: EditText
    lateinit var etPassword: EditText

    lateinit var sharedPreferences: SharedPreferences
    lateinit var login_fragment_Progressdialog: RelativeLayout


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val ttb = AnimationUtils.loadAnimation(this, R.anim.ttb)
        val stb = AnimationUtils.loadAnimation(this, R.anim.stb)
        val btnloginanim = AnimationUtils.loadAnimation(this, R.anim.btnloginanim)


        sharedPreferences =
            getSharedPreferences(getString(R.string.preference_file_name), Context.MODE_PRIVATE)


        setContentView(R.layout.activity_login)






        if (sharedPreferences.getBoolean("isLoggedIn", false)) {
            val intent1 = Intent(this@Login, Welcomescreen::class.java)
            startActivity(intent1)
            finish();
        }



        title = "Log In"
        etMobileNumber = findViewById(R.id.etmobileno)
        etPassword = findViewById(R.id.etPassword)

        etMobileNumber.startAnimation(ttb)
        etPassword.startAnimation(ttb)
        /*loginimage = findViewById(R.id.imageViewAppIcon)*/
        btnLogin = findViewById(R.id.btnlogin)
        btnLogin.startAnimation(btnloginanim)
        /*imageViewAppIcon.startAnimation(stb)*/
        login_fragment_Progressdialog = findViewById(R.id.login_fragment_Progressdialog)


        login_fragment_Progressdialog.visibility = View.INVISIBLE


        txtforgot = findViewById(R.id.txtForgot)
        txtforgot.paintFlags = Paint.UNDERLINE_TEXT_FLAG

        txtforgot.startAnimation(btnloginanim)

        txtforgot.setOnClickListener {

            val intent = Intent(this, ForgotPassword::class.java)
            startActivity(intent)

        }

        txtRegister = findViewById(R.id.txt_register)
        txtRegister.paintFlags = Paint.UNDERLINE_TEXT_FLAG
        txtRegister.startAnimation(btnloginanim)
        txtRegister.setOnClickListener {

            val intent2 = Intent(this, Registration::class.java)
            startActivity(intent2)
        }

        btnLogin.setOnClickListener(View.OnClickListener {


            btnLogin.visibility = View.VISIBLE
            if (etMobileNumber.text.isBlank()) {
                etMobileNumber.setError("Mobile Number Missing")
                btnLogin.visibility = View.VISIBLE

            } else {
                if (etPassword.text.isBlank()) {
                    btnLogin.visibility = View.VISIBLE
                    etPassword.setError("Missing Password")
                } else {
                    loginUserFun()
                }
            }

        })

    }


    fun loginUserFun() {

        val sharedPreferencess =
            getSharedPreferences(getString(R.string.preference_file_name), Context.MODE_PRIVATE)

        if (ConnectionManager().checkConnectivity(this)) {

            //login_fragment_Progressdialog.visibility=View.VISIBLE
            try {

                val loginUser = JSONObject()

                loginUser.put("mobile_number", etMobileNumber.text)
                loginUser.put("password", etPassword.text)


                /*savePreferences(etMobileNumber.toString(),etPassword.toString())
                val intent=Intent(this@Login,Welcomescreen::class.java)
                startActivity(intent)
                finish();*/

                val queue = Volley.newRequestQueue(this)

                val url = "http://" + getString(R.string.ip_address) + "/v2/login/fetch_result"

                val jsonObjectRequest = object : JsonObjectRequest(
                    Request.Method.POST,
                    url,
                    loginUser,
                    Response.Listener {

                        val responseJsonObjectData = it.getJSONObject("data")

                        val success = responseJsonObjectData.getBoolean("success")


                        if (success) {

                            val data = responseJsonObjectData.getJSONObject("data")
                            sharedPreferencess.edit().putBoolean("isLoggedIn", true).commit()
                            sharedPreferencess.edit()
                                .putString("user_id", data.getString("user_id")).commit()
                            sharedPreferencess.edit().putString("name", data.getString("name"))
                                .apply()
                            sharedPreferencess.edit().putString("email", data.getString("email"))
                                .apply()
                            sharedPreferencess.edit()
                                .putString("mobile_number", data.getString("mobile_number")).apply()
                            sharedPreferencess.edit()
                                .putString("address", data.getString("address")).apply()

                            Toast.makeText(
                                this,
                                "Welcome " + data.getString("name"),
                                Toast.LENGTH_SHORT
                            ).show()

                            userSuccessfullyLoggedIn()//after we get a response we call the Log the user in

                        } else {

                            btnLogin.visibility = View.VISIBLE

                            println(it)

                            val responseMessageServer =
                                responseJsonObjectData.getString("errorMessage")
                            Toast.makeText(
                                this,
                                responseMessageServer.toString(),
                                Toast.LENGTH_SHORT
                            ).show()

                        }

                        login_fragment_Progressdialog.visibility = View.INVISIBLE
                    },
                    Response.ErrorListener {
                        println(it)
                        btnLogin.visibility = View.VISIBLE
                        login_fragment_Progressdialog.visibility = View.INVISIBLE


                        Toast.makeText(
                            this,
                            "Some Error occurred!!!",
                            Toast.LENGTH_SHORT
                        ).show()


                    }) {
                    override fun getHeaders(): MutableMap<String, String> {
                        val headers = HashMap<String, String>()

                        headers["Content-type"] = "application/json"
                        headers["token"] = "9bf534118365f1"

                        return headers
                    }
                }

                queue.add(jsonObjectRequest)

            } catch (e: JSONException) {
                btnLogin.visibility = View.VISIBLE

                Toast.makeText(
                    this,
                    "Some unexpected error occured!!!",
                    Toast.LENGTH_SHORT
                ).show()

            }

        } else {
            btnLogin.visibility = View.VISIBLE

            val alterDialog = androidx.appcompat.app.AlertDialog.Builder(this)

            alterDialog.setTitle("No Internet")
            alterDialog.setMessage("Internet Connection can't be establish!")
            alterDialog.setPositiveButton("Open Settings") { text, listener ->
                val settingsIntent = Intent(Settings.ACTION_SETTINGS)//open wifi settings
                startActivity(settingsIntent)

            }

            alterDialog.setNegativeButton("Exit") { text, listener ->
                ActivityCompat.finishAffinity(this)//closes all the instances of the app and the app closes completely
            }
            alterDialog.create()
            alterDialog.show()

        }

    }

    fun userSuccessfullyLoggedIn() {
        val intent = Intent(this, Welcomescreen::class.java)
        startActivity(intent)
        finish()
    }


    override fun onResume() {

        if (!ConnectionManager().checkConnectivity(applicationContext)) {

            val alterDialog = androidx.appcompat.app.AlertDialog.Builder(this)
            alterDialog.setTitle("No Internet")
            alterDialog.setMessage("Internet Connection can't be establish!")
            alterDialog.setPositiveButton("Open Settings") { text, listener ->
                val settingsIntent = Intent(Settings.ACTION_SETTINGS)//open wifi settings
                startActivity(settingsIntent)
            }

            alterDialog.setNegativeButton("Exit") { text, listener ->
                ActivityCompat.finishAffinity(Activity())//closes all the instances of the app and the app closes completely
            }
            alterDialog.setCancelable(false)

            alterDialog.create()
            alterDialog.show()

        }

        super.onResume()


    }

    /*  fun savePreferences(a:String,b:String)
      {
          sharedPreferences.edit().putBoolean("isLoggedIn",true).commit()
          sharedPreferences.edit().putString("a",a).apply()
          sharedPreferences.edit().putString("b",b).apply()
      }
  */

    /*override fun onPause() {
        super.onPause()
        finish()
    }*/


}



