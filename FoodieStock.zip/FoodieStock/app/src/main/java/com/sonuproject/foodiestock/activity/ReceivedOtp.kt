package com.sonuproject.foodiestock.activity

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import com.android.volley.Request
import com.android.volley.Request.Method.POST
import com.android.volley.Response
import com.android.volley.VolleyLog
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.sonuproject.foodiestock.R
import com.sonuproject.foodiestock.util.ConnectionManager
import kotlinx.android.synthetic.main.activity_receivedotp.*
import org.json.JSONObject
import java.lang.reflect.Method

class ReceivedOtp : AppCompatActivity() {

    lateinit var etotp: EditText
    lateinit var etNewPassword: EditText
    lateinit var etConfirmPassword: EditText
    lateinit var btnsubmitOTP: Button
    var mobile_number: String = "404"
    lateinit var sharedPreferences: SharedPreferences
    //private var mobile:String?="404"


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_receivedotp)

        etotp = findViewById(R.id.etOtp)
        etNewPassword = findViewById(R.id.etPassword)
        etConfirmPassword = findViewById(R.id.etConfirmPassword)
        btnsubmitOTP = findViewById(R.id.btnSubmitOTP)



        sharedPreferences =
            getSharedPreferences(getString(R.string.preference_file_name), Context.MODE_PRIVATE)

        mobile_number = sharedPreferences.getString("mobile_number", "404").toString()




        btnsubmitOTP.setOnClickListener {


            try {

                val queue = Volley.newRequestQueue(this@ReceivedOtp)
                val url = "http://13.235.250.119/v2/reset_password/fetch_result"

                val jsonParams = JSONObject()
                jsonParams.put("mobile_number", mobile_number)
                jsonParams.put("password", etNewPassword.text.toString())
                jsonParams.put("otp", etOtp.text.toString())




                if (etotp.text.isBlank()) {
                    etotp.setError("OTP Missing")
                } else {
                    if (etNewPassword.text.isBlank()) {
                        etNewPassword.setError("Password Missing")
                    } else {
                        if (etConfirmPassword.text.isBlank()) {
                            etConfirmPassword.setError("Confirm Password Missing")
                        } else {
                            if (etNewPassword.text.toString()
                                    .toInt() == etConfirmPassword.text.toString().toInt()
                            ) {


                                if (ConnectionManager().checkConnectivity(this@ReceivedOtp)) {


                                    val jsonRequest = object : JsonObjectRequest(
                                        Request.Method.POST,
                                        url,
                                        jsonParams,
                                        Response.Listener {


                                            val jsonData = it.getJSONObject("data")
                                            val success = jsonData.getBoolean("success")
                                            if (success) {
                                                Toast.makeText(
                                                    this@ReceivedOtp,
                                                    "Password has successfully changed",
                                                    Toast.LENGTH_SHORT
                                                ).show()
                                                val intent = Intent(
                                                    this@ReceivedOtp,
                                                    Login::class.java
                                                )
                                                startActivity(intent)
                                            } else {
                                                Toast.makeText(
                                                    this@ReceivedOtp,
                                                    "Error-${it}",
                                                    Toast.LENGTH_SHORT
                                                ).show()
                                            }


                                        },
                                        Response.ErrorListener {
                                            Toast.makeText(
                                                this@ReceivedOtp,
                                                "Volley Error-${it}",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        }) {
                                        override fun getHeaders(): MutableMap<String, String> {
                                            val headers = HashMap<String, String>()
                                            headers["Content-Type"] = "application/json"
                                            headers["token"] = "9bf534118365f1"


                                            return headers
                                        }


                                    }
                                    queue.add(jsonRequest)


                                } else {
                                    val dialog = AlertDialog.Builder(this@ReceivedOtp)
                                    dialog.setTitle("Error")
                                    dialog.setMessage("Internet Connection not found ")
                                    dialog.setPositiveButton("Open Settings") { text, listener ->
                                        val settingsIntent =
                                            Intent(Settings.ACTION_WIRELESS_SETTINGS)
                                        startActivity(settingsIntent)
                                        finish()


                                    }
                                    dialog.setNegativeButton("Exit") { text, listener ->
                                        ActivityCompat.finishAffinity(this@ReceivedOtp)


                                    }
                                    dialog.create()
                                    dialog.show()
                                }


                            } else {
                                etNewPassword.setError("PASSWORD DONT MATCH")
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Toast.makeText(this@ReceivedOtp, "Error-${e}", Toast.LENGTH_SHORT).show()
            }


        }

    }
}