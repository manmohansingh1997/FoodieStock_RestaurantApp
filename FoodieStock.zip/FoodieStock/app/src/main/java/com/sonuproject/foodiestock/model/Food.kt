package com.sonuproject.foodiestock.model

data class Food(

    var foodId:Int,
    var foodName:String,
    var foodRating: String,
    var foodPrice: String,
    var foodImage: String



)


