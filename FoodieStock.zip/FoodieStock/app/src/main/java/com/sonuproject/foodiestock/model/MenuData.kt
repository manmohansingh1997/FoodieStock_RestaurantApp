package com.sonuproject.foodiestock.model

data class MenuData (
    var id:String,
    var name: String,
    var cost: String
)