package com.sonuproject.foodiestock.model

data class CartItems (var itemId:Int,
                      var itemName:String,
                      var itemPrice:String,
                      var restaurantId:String)