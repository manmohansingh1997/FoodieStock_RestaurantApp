package com.sonuproject.foodiestock.database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "Food")
data class FoodEntity(

    @PrimaryKey val foodId: Int,
    @ColumnInfo(name = "name") var foodName: String,
    @ColumnInfo(name = "rating") var foodRating: String,
    @ColumnInfo(name = "cost_for_one") var foodPrice: String,
    @ColumnInfo(name = "image_url") var foodImage:String

)