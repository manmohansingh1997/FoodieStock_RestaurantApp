package com.sonuproject.foodiestock.fragment

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.AsyncTask
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.sonuproject.foodiestock.R
import com.sonuproject.foodiestock.adapter.HomeRecyclerAdapter
import com.sonuproject.foodiestock.database.FoodDatabase
import com.sonuproject.foodiestock.database.FoodEntity
import com.sonuproject.foodiestock.model.Food
import com.sonuproject.foodiestock.util.ConnectionManager
import kotlinx.android.synthetic.main.sort_radio_button.view.*
import org.json.JSONException
import org.json.JSONObject
import java.util.*
import kotlin.Comparator
import kotlin.collections.HashMap


class HomeFragment(val contextParam: Context) : Fragment() {


    lateinit var recyclerHome: RecyclerView
    lateinit var progressBar: ProgressBar
    lateinit var progressLayout: RelativeLayout
    lateinit var layoutManager: RecyclerView.LayoutManager
    lateinit var recyclerAdapter: HomeRecyclerAdapter
    lateinit var radioButtonView: View
    lateinit var editTextSearch: EditText
    lateinit var dashboard_fragment_cant_find_restaurant: RelativeLayout


    val foodInfoList = arrayListOf<Food>()

    var ratingCompare = Comparator<Food> { food1, food2 ->

        if (food1.foodRating.compareTo(food2.foodRating, true) == 0) {
            food1.foodImage.compareTo(food2.foodImage, true)
        } else {
            food1.foodRating.compareTo(food2.foodRating, true)
        }
    }

    var costComparator = Comparator<Food> { rest1, rest2 ->

        rest1.foodPrice.compareTo(rest2.foodPrice, true)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        setHasOptionsMenu(true)
        val view = inflater.inflate(R.layout.fragment_home, container, false)



        recyclerHome = view.findViewById(R.id.recyclerhome)
        progressLayout = view.findViewById(R.id.progressLayout)
        progressBar = view.findViewById(R.id.progressBar)
        editTextSearch = view.findViewById(R.id.editTextSearch)
        dashboard_fragment_cant_find_restaurant =
            view.findViewById(R.id.dashboard_fragment_cant_find_restaurant)
        layoutManager = LinearLayoutManager(activity)

        progressLayout.visibility = View.VISIBLE
        progressBar.visibility = View.VISIBLE


        fun filterFun(strTyped: String) {//to filter the recycler view depending on what is typed
            val filteredList = arrayListOf<Food>()

            for (item in foodInfoList) {
                if (item.foodName.toLowerCase()
                        .contains(strTyped.toLowerCase())
                ) {//to ignore case and if contained add to new list

                    filteredList.add(item)

                }
            }

            if (filteredList.size == 0) {
                dashboard_fragment_cant_find_restaurant.visibility = View.VISIBLE
            } else {
                dashboard_fragment_cant_find_restaurant.visibility = View.INVISIBLE
            }

            recyclerAdapter.filterList(filteredList)

        }

        editTextSearch.addTextChangedListener(object : TextWatcher {
            //as the user types the search filter is applied
            override fun afterTextChanged(strTyped: Editable?) {
                filterFun(strTyped.toString())
            }

            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }
        }
        )


        val queue = Volley.newRequestQueue(activity as Context)
        val url = "http://13.235.250.119/v2/restaurants/fetch_result/"

        if (ConnectionManager().checkConnectivity(activity as Context)) {
            val jsonObjectRequest = object :
                JsonObjectRequest(Request.Method.GET, url, null, Response.Listener<JSONObject> {

                    try {

                        val data = it.getJSONObject("data")
                        val success = data.getBoolean("success")
                        if (success) {
                            progressBar.visibility = View.GONE
                            progressLayout.visibility = View.GONE

                            val resArray = data.getJSONArray("data")
                            for (i in 0 until resArray.length()) {
                                val resObject = resArray.getJSONObject(i)
                                val restaurant = Food(
                                    resObject.getString("id").toInt(),
                                    resObject.getString("name"),

                                    resObject.getString("rating"),
                                    resObject.getString("cost_for_one"),
                                    resObject.getString("image_url")
                                )

                                foodInfoList.add(restaurant)

                                recyclerAdapter =
                                    HomeRecyclerAdapter(activity as Context, foodInfoList)
                                recyclerHome.adapter = recyclerAdapter
                                recyclerHome.layoutManager = layoutManager

                                /*recyclerHome.addItemDecoration(
                                    DividerItemDecoration(
                                        recyclerHome.context,
                                        (layoutManager as LinearLayoutManager).orientation*/

                            }
                        } else {
                            Toast.makeText(
                                activity as Context,
                                "Some Error Occurred",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    } catch (e: JSONException) {
                        Toast.makeText(activity as Context, "Unexpected Error", Toast.LENGTH_SHORT)
                            .show()
                    }

                }, Response.ErrorListener {
                    if (activity != null) {
                        Toast.makeText(activity as Context, "Volley Error", Toast.LENGTH_SHORT)
                            .show()
                    }
                }) {
                override fun getHeaders(): MutableMap<String, String> {
                    val headers = HashMap<String, String>()
                    headers["Content-type"] = "application/json"
                    headers["token"] = "9bf534118365f1"
                    return headers
                }

            }
            queue.add(jsonObjectRequest)


        } else {
            val dialog = AlertDialog.Builder(activity as Context)
            dialog.setTitle("Failed")
            dialog.setMessage("Internet Connection Not Found")
            dialog.setPositiveButton("Open Settings") { text, listener ->
                val settingsIntent = Intent(Settings.ACTION_WIRELESS_SETTINGS)
                startActivity(settingsIntent)
                activity?.finish()
            }
            dialog.setNegativeButton("Cancel") { text, listener ->
                ActivityCompat.finishAffinity(activity as Activity)

            }
            dialog.create()
            dialog.show()
        }

        return view
    }
//context is used to access database
    class DBAsyncTask(val context: Context, val FoodEntity: FoodEntity, val mode: Int) :
        AsyncTask<Void, Void, Boolean>() {

        val db = Room.databaseBuilder(context, FoodDatabase::class.java, "food-db").build()
        override fun doInBackground(vararg params: Void?): Boolean {

            when (mode) {

                1 -> {
                    val food: FoodEntity? = db.foodDao().getFoodById(FoodEntity.foodId.toString())
                    db.close()
                    return food != null
                }

                2 -> {
                    db.foodDao().insertFood(FoodEntity)
                    db.close()
                    return true
                }

                3 -> {
                    db.foodDao().deleteFood(FoodEntity)
                    db.close()
                    return true
                }




            }

            return false
        }
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater?.inflate(R.menu.menu_dashboard, menu)

    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        val id = item.itemId

        when (id) {

            R.id.action_sort -> {
                radioButtonView = View.inflate(
                    contextParam,
                    R.layout.sort_radio_button,
                    null
                )//radiobutton view for sorting display
                androidx.appcompat.app.AlertDialog.Builder(activity as Context)
                    .setTitle("Sort By?")
                    .setView(radioButtonView)
                    .setPositiveButton("OK") { text, listener ->
                        if (radioButtonView.radio_high_to_low.isChecked) {
                            Collections.sort(foodInfoList, costComparator)
                            foodInfoList.reverse()
                            recyclerAdapter.notifyDataSetChanged()//updates the adapter
                        }
                        if (radioButtonView.radio_low_to_high.isChecked) {
                            Collections.sort(foodInfoList, costComparator)
                            recyclerAdapter.notifyDataSetChanged()//updates the adapter
                        }
                        if (radioButtonView.radio_rating.isChecked) {
                            Collections.sort(foodInfoList, ratingCompare)
                            foodInfoList.reverse()
                            recyclerAdapter.notifyDataSetChanged()//updates the adapter
                        }
                    }
                    .setNegativeButton("CANCEL") { text, listener ->

                    }
                    .create()
                    .show()
            }
        }

        return super.onOptionsItemSelected(item)
    }
}








