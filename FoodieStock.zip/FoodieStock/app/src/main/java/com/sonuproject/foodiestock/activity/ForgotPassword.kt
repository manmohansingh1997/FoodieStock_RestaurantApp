package com.sonuproject.foodiestock.activity

import android.app.AlertDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.core.app.ActivityCompat
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.sonuproject.foodiestock.R
import com.sonuproject.foodiestock.util.ConnectionManager
import org.json.JSONObject

class ForgotPassword : AppCompatActivity() {


    lateinit var button: Button

    lateinit var etForgotMobile: EditText
    lateinit var etForgotEmail: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgotpassword)

        etForgotMobile = findViewById(R.id.etForgotMobile)
        etForgotEmail = findViewById(R.id.etForgotEmail)

        button = findViewById(R.id.btnlogin)


        button.setOnClickListener {


            val number = etForgotMobile.text.toString()
            val email = etForgotEmail.text.toString()


            val queue = Volley.newRequestQueue(this@ForgotPassword)
            val url = "http://13.235.250.119/v2/forgot_password/fetch_result"

            val jsonParams = JSONObject()
            jsonParams.put("mobile_number", number)
            jsonParams.put("email", email)

            if (ConnectionManager().checkConnectivity(this)) {


                val jsonRequest = object :

                    JsonObjectRequest(Request.Method.POST, url, jsonParams, Response.Listener {

                        try {


                            println("response is $it")

                            val data = it.getJSONObject("data")

                            val success = data.getBoolean("success")

                            if (success) {
                                val first_try = data.getBoolean("first_try")
                                val intent = Intent(
                                    this@ForgotPassword,
                                    ReceivedOtp::class.java
                                )
                                startActivity(intent)


                            } else {
                                Toast.makeText(this, "error occured $it", Toast.LENGTH_LONG).show()
                            }

                        } catch (e: Exception) {
                            Toast.makeText(this, "some exception occured $e", Toast.LENGTH_LONG)
                                .show()
                        }

                    }, Response.ErrorListener {

                        Toast.makeText(this, "Error Occure $it", Toast.LENGTH_LONG).show()
                    }) {
                    override fun getHeaders(): MutableMap<String, String> {
                        val headers = HashMap<String, String>()
                        headers["Content-type"] = "application/json"
                        headers["token"] = "9bf534118365f1"
                        return headers
                    }
                }

                queue.add(jsonRequest)
            } else {
                val dialog = AlertDialog.Builder(this)
                dialog.setTitle("Error")
                dialog.setMessage("Internet Connection Not Found. Turn On Internet Connection And Restart App")
                dialog.setPositiveButton("Close") { text, listner ->
                    ActivityCompat.finishAffinity(this)
                }
                dialog.create()
                dialog.show()
            }
        }


    }
}
